/*const btnC = document.getElementById('btnConsumer');
const btnD = document.getElementById('btnDev');
const btnE = document.getElementById('btnExamples');
*/
const consumerSection = document.getElementById('contentConsumer');
const devSection = document.getElementById('contentDev');
const barbieSection = document.getElementById('barbiePlaceholder');

// Smooth scroll function
function scrollToEl(el) {
  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Add active visual (optional)
function setActive(btn) {
  document.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}
/*
// Event listeners
btnC.addEventListener('click', () => {
  setActive(btnC);
  scrollToEl(consumerSection);
});

btnD.addEventListener('click', () => {
  setActive(btnD);
  scrollToEl(devSection);
});

btnE.addEventListener('click', () => {
  setActive(btnE);
  scrollToEl(barbieSection);
  barbieSection.animate(
    [
      { boxShadow: '0 0 0 rgba(255,92,138,0)' },
      { boxShadow: '0 0 20px rgba(255,92,138,0.3)' },
      { boxShadow: '0 0 0 rgba(255,92,138,0)' }
    ],
    { duration: 900, easing: 'ease-out' }
  );
});
*/
